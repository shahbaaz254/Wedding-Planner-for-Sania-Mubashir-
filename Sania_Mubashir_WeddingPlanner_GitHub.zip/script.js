const PASSWORD = "SaniaMubashir2026";
const weddingDate = new Date("June 15, 2026");
const plateCost = 1200;
const totalBudget = 3000000;

let guests = JSON.parse(localStorage.getItem("guests")) || [];
let vendors = JSON.parse(localStorage.getItem("vendors")) || [];
let tasks = JSON.parse(localStorage.getItem("tasks")) || [];

function unlockApp() {
  if(document.getElementById("passwordInput").value === PASSWORD){
    document.getElementById("lockScreen").style.display="none";
    document.getElementById("appContent").style.display="block";
    init();
  } else alert("Wrong Password");
}

function toggleDarkMode(){
  document.body.classList.toggle("dark");
}

function init(){
  updateCountdown();
  renderGuests();
  renderVendors();
  renderTasks();
}

function updateCountdown(){
  const diff = weddingDate - new Date();
  const days = Math.ceil(diff/(1000*60*60*24));
  document.getElementById("countdown").innerText = days+" Days To Go 💍";
}

function showSection(id){
  document.querySelectorAll("section").forEach(s=>s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function addGuest(){
  guests.push({
    name:guestName.value,
    side:guestSide.value,
    rsvp:guestRSVP.value,
    count:Number(guestCount.value)
  });
  localStorage.setItem("guests",JSON.stringify(guests));
  renderGuests();
}

function renderGuests(){
  guestList.innerHTML="";
  let bride=0,groom=0,confirmed=0;

  guests.forEach((g,i)=>{
    if(g.side==="Bride") bride+=g.count;
    if(g.side==="Groom") groom+=g.count;
    if(g.rsvp==="Yes") confirmed+=g.count;

    guestList.innerHTML+=`<li>${g.name} (${g.side}) - ${g.count} - ${g.rsvp}</li>`;
  });

  guestStats.innerHTML=`
  Bride: ${bride} | Groom: ${groom}<br>
  Confirmed: ${confirmed}<br>
  Catering Est: ₹${confirmed*plateCost}
  `;

  new Chart(document.getElementById("guestChart"),{
    type:"pie",
    data:{labels:["Bride","Groom"],
    datasets:[{data:[bride,groom]}]}
  });
}

function addVendor(){
  vendors.push({
    name:vendorName.value,
    category:vendorCategory.value,
    advance:Number(vendorAdvance.value)
  });
  localStorage.setItem("vendors",JSON.stringify(vendors));
  renderVendors();
}

function renderVendors(){
  vendorList.innerHTML="";
  vendors.forEach(v=>{
    vendorList.innerHTML+=`<li>${v.name} - ${v.category} - ₹${v.advance}</li>`;
  });
}

function addTask(){
  tasks.push({task:taskInput.value,done:false});
  localStorage.setItem("tasks",JSON.stringify(tasks));
  renderTasks();
}

function renderTasks(){
  taskList.innerHTML="";
  let completed=0;
  tasks.forEach((t,i)=>{
    if(t.done) completed++;
    taskList.innerHTML+=`<li>
    <input type="checkbox" ${t.done?"checked":""}
    onchange="toggleTask(${i})"> ${t.task}
    </li>`;
  });
  taskProgress.innerText=`Completion: ${Math.round((completed/tasks.length)*100)||0}%`;
}

function toggleTask(i){
  tasks[i].done=!tasks[i].done;
  localStorage.setItem("tasks",JSON.stringify(tasks));
  renderTasks();
}